# importar bibliotecas
# quem sera utilizado
#import machine # machine.Pin
from machine import PWM, Pin, ADC
from time import sleep

# configuracao
# onde estao os itens/componentes
# 50 é o valor da frequência do motor
servo_01 = PWM(Pin(23, Pin.OUT), 50)
servo_02 = PWM(Pin(22, Pin.OUT), 50)

potenciometro_01 = ADC(Pin(12))
potenciometro_01.atten(ADC.ATTN_11DB)
potenciometro_01.width(ADC.WIDTH_10BIT)

potenciometro_02 = ADC(Pin(2))
potenciometro_02.atten(ADC.ATTN_11DB)
potenciometro_02.width(ADC.WIDTH_10BIT)

# programa
# o que / como ira acontecer
# .duty é um comando para enviar informação em PWM (no MicroPython)
# Mototres aceitam valores de 25 a 126
while True:
    estado_potenciometro_01 = potenciometro_01.read()
    novo_valor = (estado_potenciometro_01 - 0) * (126 - 25) / (1023 - 0) + 25
    novo_valor = int(novo_valor)
    servo_01.duty(novo_valor)
    print("")
    sleep(1)
    print(f"O potenciômetro 1 tem o valor de: {novo_valor}")

    estado_potenciometro_02 = potenciometro_02.read()
    novo_valor2 = (estado_potenciometro_02 - 0) * (126 - 25) / (1023 - 0) + 25
    novo_valor2 = int(novo_valor2)
    servo_02.duty(novo_valor2)
    print("")
    sleep(1)
    print(f"O potenciômetro 2 tem o valor de: {novo_valor2}")
