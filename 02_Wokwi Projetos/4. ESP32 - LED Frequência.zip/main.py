# importar bibliotecas
# quem sera utilizado
#import machine # machine.Pin
from machine import Pin
from time import sleep

# configuracao
# onde estao os itens/componentes
led_01 = Pin(26, Pin.OUT)

# programa
# o que / como ira acontecer

while True:
    frequência = 0.2
    led_01.value(1)
    sleep(frequência)
    led_01.value(0)
    sleep(frequência)