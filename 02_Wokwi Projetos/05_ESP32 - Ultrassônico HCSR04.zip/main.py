# importar bibliotecas
# quem sera utilizado
#import machine # machine.Pin
from machine import Pin
from hcsr04 import HCSR04
from time import sleep

# configuracao
# onde estao os itens/componentes
led_01 = Pin(25, Pin.OUT)
led_02 = Pin(21, Pin.OUT)
TRIG = Pin(13)
ECHO = Pin(12)
ultrassonico = HCSR04(trigger_pin = TRIG, echo_pin = ECHO)

# programa
# o que / como ira acontecer
var_cm = ultrassonico.distance_cm()
var_mm = ultrassonico.distance_mm()

while True:
    var_cm = ultrassonico.distance_cm()
    print("")
    print(f"CM: {var_cm}")
    sleep(1)
    if var_cm >= 300:
        frequencia = 1
        led_01.value(1)
        sleep(frequencia)
        led_01.value(0)
        sleep(frequencia)
    elif var_cm >= 150 and var_cm < 300:
        frequencia = 0.5
        led_01.value(1)
        sleep(frequencia)
        led_01.value(0)
        sleep(frequencia)
    elif var_cm >= 50 and var_cm < 150:
        frequencia = 0.5
        led_02.value(1)
        sleep(frequencia)
        led_02.value(0)
        sleep(frequencia)
    elif var_cm < 50:
        frequencia = 0.1
        led_02.value(1)
        sleep(frequencia)
        led_02.value(0)
        sleep(frequencia)