from machine import Pin, PWM
from time import sleep

# ==========================================
# 1. CONFIGURAÇÃO DE HARDWARE (PWM)
# ==========================================

buzzer = PWM(Pin(15))

# Inicia com o buzzer desligado (Volume 0)
buzzer.duty(0)
buzzer.freq(400) # Define a nota (tom/altura do som) de 100 a 5000
buzzer.duty(512) # Define o volume para 50% (512 de 1023)
sleep(5) # Mantém o som tocando
buzzer.duty(0)