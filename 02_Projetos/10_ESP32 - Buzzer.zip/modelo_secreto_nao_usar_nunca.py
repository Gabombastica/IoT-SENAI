from machine import Pin, PWM
from time import sleep

# Configura o pino do Buzzer
buzzer = PWM(Pin(15))
buzzer.duty(0) # Inicia mudo

# ==========================================
# 1. TABELA DE NOTAS MUSICAIS (Em Hertz)
# ==========================================
NOTAS = {
    'G4': 392,  # Sol grave
    'C5': 523,  # Dó
    'E5': 659,  # Mi
    'G5': 784,  # Sol agudo
    'PAUSA': 0  # Silêncio
}

# ==========================================
# 2. PARTITURA: SUPER MARIO BROS (Introdução)
# Formato: ('NOTA', Multiplicador de Tempo)
# ==========================================
mario_intro = [
    ('E5', 1), ('PAUSA', 1),
    ('E5', 1), ('PAUSA', 1),
    ('E5', 1), ('PAUSA', 1),
    ('C5', 1), ('E5', 2), 
    ('G5', 2), ('PAUSA', 2),
    ('G4', 2), ('PAUSA', 2)
]

# Velocidade base da música (Tempo de 1 batida em segundos)
TEMPO_BASE = 0.15

# ==========================================
# 3. FUNÇÃO TOCADOR DE MÚSICA
# ==========================================
def tocar_musica(partitura, tempo):
    for nota, duracao in partitura:
        frequencia = NOTAS[nota]
        tempo_total = duracao * tempo
        
        if frequencia == 0:
            # É uma pausa, fica mudo
            buzzer.duty(0)
            sleep(tempo_total)
        else:
            # É uma nota, toca o som
            buzzer.freq(frequencia)
            buzzer.duty(512) # Volume 50%
            
            # Segura a nota tocando
            sleep(tempo_total)
            
            # Dica de Engenharia: Uma micro-pausa (staccato) entre as notas 
            # para que duas notas iguais seguidas não pareçam um som só longo.
            buzzer.duty(0)
            sleep(0.02) 

# ==========================================
# 4. LOOP PRINCIPAL
# ==========================================
while True:
    print("Tocando Super Mario Bros...")
    tocar_musica(mario_intro, TEMPO_BASE)
    
    print("Aguardando 3 segundos...")
    sleep(3)