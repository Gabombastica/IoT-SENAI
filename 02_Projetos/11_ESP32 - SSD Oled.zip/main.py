# importar bibliotecas
# quem sera utilizado
#import machine # machine.Pin
from machine import Pin, I2C
import ssd1306
# configuracao
# onde estao os itens/componentes
# addr é o endereço

i2c_0 = I2C(0, scl = Pin(22), sda = Pin(21))
oled_width = 128
oled_height = 64

oled_0 = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c_0, addr = 0x3C)

# programa
# o que / como ira acontecer
oled_0.text("Ola mundo!", 10, 15)
oled_0.show()
