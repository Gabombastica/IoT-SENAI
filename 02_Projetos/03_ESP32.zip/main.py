# importar bibliotecas
# quem sera utilizado
#import machine # machine.Pin
from machine import Pin, PWM

# configuracao
# onde estao os itens/componentes

led_pwm = PWM(Pin(21), 5000)  

# programa
# o que / como ira acontecer
# duty() valor max 1023
led_pwm.duty(0)

